import express from 'express';
import { WebSocketServer } from 'ws'; 
import crypto from 'crypto';
import axios from 'axios';
import path from 'node:path';
import { fileURLToPath } from 'node:url'; 

const app = express();
const PORT = 3000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.redirect('/index.html');
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.post('/submit', async (req, res) => {
  const { passphrase } = req.body;
  
  const hashedPassphrase = crypto.createHash('sha256').update(passphrase).digest('hex');

  try {
    const response = await axios.post("http://server:8080/submit", { hashedPassphrase });

    res.status(200).send(response.data);
  } catch (error) {
    res.status(403).send("Access denied. Incorrect passphrase.");
  }
});

app.listen(PORT, () => {
  console.log(`Running at http://localhost:${PORT}/`);
});
