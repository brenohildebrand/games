import express from 'express';
import { WebSocketServer } from 'ws';
import path from 'node:path';
import { fileURLToPath } from 'node:url'; 

const app = express();
const PORT = 8080;
const SECRET = "aHR0cHM6Ly93d3cueW91dHViZS5jb20vd2F0Y2g/dj1kUXc0dzlXZ1hjUQ==";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  
  wss.clients.forEach((client) => {
    if (client.readyState === client.OPEN)
    {
      if (req.body && req.body.hashedPassphrase)
      {
        client.send(`[${timestamp}]\t${req.method}\t${req.url}`);
        if (req.body.hashedPassphrase === "bfe7aed882c372f401be8b849c503547d9872088e4ad361d71babd34123bf51b")
          client.send(`[${timestamp}] Heck yeah! Hope you trust your friends, Mr. Nobody.`);
        else if (req.body.hashedPassphrase !== "bfe7aed882c372f401be8b849c503547d9872088e4ad361d71babd34123bf51b")
          client.send(`[${timestamp}] ALERT! SOMEONE MAY BE TRYING TO STEAL THE SECRET.`)
      }
      else
      {
        client.send(`[${timestamp}]\t${req.method}\t${req.url}`);
      }
    }
  });

  next();
});
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.redirect('/index.html');
});

app.post('/submit', (req, res) => {
  const { hashedPassphrase } = req.body;
  
  if (hashedPassphrase === "bfe7aed882c372f401be8b849c503547d9872088e4ad361d71babd34123bf51b")
    res.status(200).send(Buffer.from(SECRET, 'base64').toString('utf-8'));
  else
    res.status(403).send('Access denied.');
});

const server = app.listen(PORT, () => {
  console.log(`Running at http://localhost:${PORT}/`);
});

const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {});
