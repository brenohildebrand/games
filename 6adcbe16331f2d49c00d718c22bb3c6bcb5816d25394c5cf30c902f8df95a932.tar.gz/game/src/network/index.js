import crypto from 'node:crypto';
import axios from 'axios';

const getRandomDelay = () => Math.floor(Math.random() * 4000) + 3000;

const sendRandomRequest = async () => {
  const randomData = crypto.randomBytes(32);
  const randomSHA256 = crypto.createHash('sha256').update(randomData).digest('hex');

  try {
    const randomIndex = Math.floor(Math.random() * 4);

    if (randomIndex === 0)
      await axios.post('http://server:8080/submit', { hashedPassphrase: 'bfe7aed882c372f401be8b849c503547d9872088e4ad361d71babd34123bf51b' });
    else if (randomIndex == 1)
      await axios.post('http://server:8080/submit', { hashedPassphrase: randomSHA256 });
    else
      await axios.get('http://server:8080/');
  } catch (error) {
    if (error.status != 403)
      console.error('Whoops... Something weird happened.');
  }

  setTimeout(sendRandomRequest, getRandomDelay());
};

sendRandomRequest();
